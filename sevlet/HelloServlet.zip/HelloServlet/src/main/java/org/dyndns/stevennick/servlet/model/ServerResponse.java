package org.dyndns.stevennick.servlet.model;

public class ServerResponse {

	private int status;
	private String result;

	public ServerResponse() {

	}

	public ServerResponse(int status, String result) {
		this.status = status;
		this.result = result;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
