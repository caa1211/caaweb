﻿
var tipTmp =  "<div class='vmRestip'>"+
            "<div class='cpu'>CPU: <span><%= cpu %></span></div>" +
            "<div class='mem'>Memory: <span><%= mem %></span></div>" +
            "<div class='disk'>Disk: <span><%= disk %></span></div>" +
            "</div>";
            
var maskTmp = "<span class='mask'></span>";